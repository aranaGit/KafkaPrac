package net.javaguides.springbootkafkaprac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootKafkaPracApplicationTests {

	@Test
	void contextLoads() {
	}

}
